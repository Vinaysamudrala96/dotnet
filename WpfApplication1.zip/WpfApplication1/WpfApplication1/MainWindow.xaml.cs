﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_display_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities contextObj = new WpfApplication1.Sep19CHNEntities();
        
            var query = from CustomerCare cust in contextObj.CustomerCares
                        select cust;
            dg_cust.ItemsSource = query.ToList();
        }


       

        private void btn_delete_Click_1(object sender, RoutedEventArgs e)
        {

            Sep19CHNEntities contextObj = new WpfApplication1.Sep19CHNEntities();
            CustomerCare custToBeDeleted = new WpfApplication1.CustomerCare();
            try
            {
                int cusId = Convert.ToInt32(txt_custId.Text);
                custToBeDeleted = contextObj.CustomerCares.FirstOrDefault(cust => cust.CustId == cusId);
                if (custToBeDeleted != null)
                {
                    contextObj.CustomerCares.Remove(custToBeDeleted);
                    contextObj.SaveChanges();
                    MessageBox.Show("Customer details deleted");
                }
                else throw new Exception("delete could not be done");
            }

            catch (Exception ex)
            {
                throw;
            }
        }
    }
    }

