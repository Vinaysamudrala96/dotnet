create table Manish.GuestPhoneBook
(
g_id int identity(1000,1),
g_name varchar(30),
g_relation varchar(30),
g_phone bigint
)

insert into Manish.GuestPhoneBook values('Rashmi','Friend',7769942667)


select * from Manish.GuestPhoneBook

create table Manish.EmployeeDept
(
EmpId int identity(1000,1),
EmpName varchar(30),
EmpLocation varchar(30),
EmpContact bigint,
DeptId int
FOREIGN KEY (DeptId) REFERENCES Manish.Department(DeptId)
)


create table Manish.Department
(
DeptId int primary key,
DeptName varchar(30),

)

 create proc Manish.usp_AddEmployeeDept
 @ename varchar(20),
 @eLoc varchar(20),
 @ePh bigint,
 @deId int
 AS
 BEGIN
 insert into Manish.EmployeeDept values(@ename,@eLoc,@ePh,@deId)
 END

  create proc Manish.usp_updateEmployeeDept
 @eID int,
 @ename varchar(20),
 @eLoc varchar(20),
 @ePh bigint,
 @deId int
 AS
 BEGIN
 Update Manish.EmployeeDept set EmpName=@ename,EmpLocation=@eLoc,EmpContact=@ePh,DeptId=@deId
 where EmpId=@eID
 END

create proc Manish.usp_SearchEmployeeDept
 @eid int
 AS
 BEGIN
 select * from Manish.EmployeeDept where EmpID=@eid
 END 

 Exec Manish.usp_SearchEmployeeDept 1003

 create proc Manish.usp_DisplayEmployeeDept
 AS
 BEGIN
 select * from Manish.EmployeeDept 
 END 


drop proc Manish.usp_SearchEmployeeDept

create proc Manish.usp_DeleteEmployeeDept
 @eid int
 AS
 BEGIN
 delete from Manish.EmployeeDept where EmpID=@eid
 END

 create proc Manish.usp_DisplayDept
 AS
 BEGIN
 select * from Manish.Department
 END
 
Exec Manish.usp_DisplayDept
Exec Manish.usp_DisplayEmployeeDept

insert into Manish.Department values(107,'HR')


create proc Manish.usp_GetEmployeeId
@empId int 
as
BEGIN


END