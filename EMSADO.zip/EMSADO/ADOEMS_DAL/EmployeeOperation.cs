﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using EMSADO_Entity;
using EMSADO_Exception;

namespace ADOEMS_DAL
{
    public class EmployeeOperation
    {
        static string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection empConnObj;
        SqlCommand empCommand;
        DataTable dtDept, dtEmp;
        SqlDataReader empReader = null;

        public EmployeeOperation()
        {
            empConnObj = new SqlConnection();
            empConnObj.ConnectionString = empConnStr;
        }


        public DataTable LoadDeparment()
        {

            try
            {
                dtDept = new DataTable();
                empCommand = new SqlCommand("Manish.usp_DisplayDept", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                dtDept.Load(empReader);

            }
            catch (SqlException)
            {
                throw;

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return dtDept;
        }


        public int AddEmployee_DAL(Employee emp)
        {
            int rowsAffected = 0;
            try
            {


                empCommand = new SqlCommand("Manish.usp_AddEmployeeDept", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;//,@eLoc,@ePh,@eDeptId
                empCommand.Parameters.AddWithValue("@ename", emp.EmpName);
                empCommand.Parameters.AddWithValue("@eLoc", emp.EmpLocation);
                empCommand.Parameters.AddWithValue("@ePh", emp.EmpPhone);
                empCommand.Parameters.AddWithValue("@deId", emp.DeptId);
                empConnObj.Open();
                rowsAffected = empCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return rowsAffected;

        }

        public int UpdateEmployee_DAL(Employee emp)
        {
            int rowsAffected = 0;
            try
            {


                empCommand = new SqlCommand("Manish.usp_updateEmployeeDept", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;//,@eLoc,@ePh,@eDeptId
                empCommand.Parameters.AddWithValue("@eID", emp.EmpId);
                empCommand.Parameters.AddWithValue("@ename", emp.EmpName);
                empCommand.Parameters.AddWithValue("@eLoc", emp.EmpLocation);
                empCommand.Parameters.AddWithValue("@ePh", emp.EmpPhone);
                empCommand.Parameters.AddWithValue("@deId", emp.DeptId);
                empConnObj.Open();
                rowsAffected = empCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return rowsAffected;

        }


        public int DeleteEmployee_DAL(int empId)
        {
            int rowsAffected = 0;
            try
            {


                empCommand = new SqlCommand("Manish.usp_DeleteEmployeeDept", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;//,@eLoc,@ePh,@eDeptId
                empCommand.Parameters.AddWithValue("@eid", empId);
                
                empConnObj.Open();
                rowsAffected = empCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return rowsAffected;

        }



        public DataTable GetEmployee_DAL()
        {
            try
            {
                dtEmp = new DataTable();
                empCommand = new SqlCommand("Manish.usp_DisplayEmployeeDept", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dtEmp.Load(empReader);
                }
            }
            catch (SqlException )
            {

                throw;
            }
            catch (Exception )
            {

                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return dtEmp;
        }

        public DataTable GetEmployeeByID_DAL(int empid)
        {
            try
            {
                dtEmp = new DataTable(/*int EmpId*/);
                empCommand = new SqlCommand("Manish.usp_SearchEmployeeDept", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empCommand.Parameters.AddWithValue("@eid", empid);
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dtEmp.Load(empReader);
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return dtEmp;
        }

    }
}
