﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using EMSADO_Entity;
using EMSADO_Exception;
using ADOEMS_DAL;



namespace EMSADO_BLL
{
    public class EmployeeValidation
    {
        EmployeeOperation empOperation;
        public DataTable LoadDeparment_BLL()
        {
            DataTable dtDept;
            try
            {
                empOperation = new EmployeeOperation();
                dtDept = empOperation.LoadDeparment();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtDept;
        }

        // get employee

        public DataTable GetEmployee_BLL()
        {
            DataTable dtEmp;
            try
            {
                empOperation = new EmployeeOperation();
                dtEmp = empOperation.GetEmployee_DAL();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtEmp;
        }


        //validate employee
        public bool validateEmp(Employee newEmp)
        {
            bool isValidEmp = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (newEmp.EmpName == string.Empty)
                {
                    isValidEmp = false;
                    sbError.Append("Please enter Employee Name");
                }
                if (!isValidEmp) throw new EmployeeException(sbError.ToString());
            }
            catch (EmployeeException ex)
            { throw ex; }

            return isValidEmp;
        }


        //Add employee
        public int AddEmployee_BLL(Employee newEmp)
        {
            int rowsAffected = 0;
            EmployeeOperation operationObj;
            try
            {
                if (validateEmp(newEmp))
                {
                    operationObj = new EmployeeOperation();
                    rowsAffected = operationObj.AddEmployee_DAL(newEmp);
                }
            }
            catch (EmployeeException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;

        }


        //update employee
        public int UpdateEmployee_BLL(Employee newEmp)
        {
            int rowsAffected = 0;
            EmployeeOperation operationObj;
            try
            {
                if (validateEmp(newEmp))
                {
                    operationObj = new EmployeeOperation();
                    rowsAffected = operationObj.UpdateEmployee_DAL(newEmp);
                }
            }
            catch (EmployeeException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;

        }

        //delete employee
        public int DeleteEmployee_BLL(int empId)
        {
            int rowsAffected = 0;
            EmployeeOperation operationObj;
            try
            {

                operationObj = new EmployeeOperation();
                rowsAffected = operationObj.DeleteEmployee_DAL(empId);

            }
            catch (EmployeeException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;

        }

        //get employee by id "Search"
        public DataTable GetEmployeeByID_BLL(int EmpId)
        {
            DataTable dtEmp;
            try
            {
                empOperation = new EmployeeOperation();

                dtEmp = empOperation.GetEmployeeByID_DAL(EmpId);

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {


            }
            return dtEmp;

        }
        }
}
