﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10Q3
{
    //creating delegate
    delegate int Deligate(int num1, int num2);
    class ArithmeticOperations
    {

        static int num;
        //Addition
        public static int AddNum(int p, int q)
        {
            num = p + q;
            return num;
        }

        //Substraction
        public static int SubNum(int p, int q)
        {
            num = p - q;
            return num;
        }

        //Multiplication
        public static int MultNum(int p, int q)
        {
            num = p * q;
            return num;
        }

        //Division
        public static int DivNum(int p, int q)
        {
            num = p / q;
            return num;
        }

        //Maximum Between 2
        public static int MaxNum(int p, int q)
        {
            return num = (p > q) ? p : q;

        }

        //show result
        public static int getResult()
        {
            return num;
        }

        static void Main(string[] args)
        {
            int ch, num1, num2;

            do
            {
                Console.WriteLine("Menu");
                Console.WriteLine("1.Addition::");
                Console.WriteLine("2.Subtraction::");
                Console.WriteLine("3.Multiplication::");
                Console.WriteLine("4.Divition::");
                Console.WriteLine("5.Maximum number::");

                Console.WriteLine("enter choice::");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (num)
                {
                    //case for Addition of two number
                    case 1:
                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());
                        Deligate nc1 = new Deligate(AddNum);
                        nc1(num1, num2);
                        Console.WriteLine("Addition: {0}", getResult());
                        break;

                    //case for Substraction of two number
                    case 2:

                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());
                        Deligate nc2 = new Deligate(SubNum);
                        nc2(num1, num2);
                        Console.WriteLine("Substraction: {0}", getResult());
                        break;

                    //case for Multiplication of two number
                    case 3:

                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());
                        Deligate nc3 = new Deligate(MultNum);
                        nc3(num1, num2);
                        Console.WriteLine("Multiplication: {0}", getResult());
                        break;

                    //case for Division of two number
                    case 4:

                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());
                        Deligate nc4 = new Deligate(DivNum);
                        nc4(num1, num2);
                        Console.WriteLine("Division: {0}", getResult());
                        break;

                    //case for Maximum between  two number
                    case 5:

                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());
                        Deligate nc5 = new Deligate(MaxNum);
                        nc5(num1, num2);
                        Console.WriteLine("Maximum number: {0}", getResult());
                        break;
                       //Exit
                    case 6:
                        Environment.Exit(0);
                        break;
                        //Default case for invalid choice
                    default:
                        Console.WriteLine("invalid choice");
                        break;
                }
            } while (ch != 6);
           
        }
    }
}
