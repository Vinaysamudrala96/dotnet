﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6Q1
{
    //create class cutomer with Auto Properties
    public class Customer
    {
        
        public int CustomerID { get; set; }

        
        public string CustName { get; set; }

       
        public string CustAddress { get; set; }

      
        public string CustCity { get; set; }

        
        public string CustPhoneNo { get; set; }

       
        public int CustCreditLimit { get; set; }

        public Customer()
        {
            CustomerID = 0;
            CustName = "";
            CustAddress = "";
            CustCity = "";
            CustPhoneNo = "";
            CustCreditLimit = 0;
        }

        public Customer(int CustomerID, string CustomerName, string Address, string City, string PhoneNo, int CreditLimit)
        {
            this.CustomerID = CustomerID;
            this.CustName = CustomerName;
            this.CustAddress = Address;
            this.CustCity = City;
            this.CustPhoneNo = PhoneNo;
            this.CustCreditLimit = CreditLimit;
        }
    }


    //creating user exception class
    class InvalidCreditLimitException : ApplicationException
    {
        public InvalidCreditLimitException()
            : base()
        { }

        public InvalidCreditLimitException(string message)
            : base(message)
        { }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Customer c = new Customer();
            //taking user input
            Console.Write("Enter the Customer ID : ");
            c.CustomerID = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the Customer Name : ");
            c.CustName = Console.ReadLine();

            Console.Write("Enter the Customer Address : ");
            c.CustAddress = Console.ReadLine();

            Console.Write("Enter the City : ");
            c.CustCity = Console.ReadLine();

            Console.Write("Enter the Customer Phone Number : ");
            c.CustPhoneNo = Console.ReadLine();
            //try block for code where exception may occure
            try
            {
                Console.Write("How much credit you want : ");
                c.CustCreditLimit = Convert.ToInt32(Console.ReadLine());

                if (c.CustCreditLimit > 50000)
                    throw new InvalidCreditLimitException("Limit of credit is Rs 50000, please insert a value under credit limit");
                else
                    Console.WriteLine("Amount Credited");
            }
            // catch block for catching user exception
            catch (InvalidCreditLimitException ex)
            {
                Console.WriteLine(ex.Message);
            }
            // catch block for catching System exception
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();

        }
    }
}
