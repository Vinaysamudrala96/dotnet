﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6Q2
{
    //product test class
    class ProductTest
    {
        //method for taking product details
        private static void GetProductDetails(ProductMock P)
        {
            Console.Write("Enter Product ID :");
            P.ProductID = Convert.ToInt32(Console.ReadLine());
            //throw Exception
            if (P.ProductID <= 0)
                throw new DataEntryException("Product ID must be greater than Zero");

            Console.Write("Enter Product Name :");
            P.ProductName = Console.ReadLine();
            //throw Exception
            if (P.ProductName == string.Empty)
                throw new DataEntryException("Product Name cannot be left blank");

            Console.Write("Enter Price :");
            P.ProductPrice = Convert.ToDouble(Console.ReadLine());
            //throw Exception
            if (P.ProductPrice <= 0)
                throw new DataEntryException("Price of product must be greater than Zero");
        }

        //method for display details of product
        private static void DisplayDetails(ProductMock P)
        {
            Console.WriteLine("Product Details :");
            Console.WriteLine("Product ID :" + P.ProductID);
            Console.WriteLine("Product Name :" + P.ProductName);
            Console.WriteLine("Product Price :" + P.ProductPrice);

        }

        static void Main(string[] args)
        {

            ProductMock P = new ProductMock();
            //code where exception may occure
            try
            {
                GetProductDetails(P);
                DisplayDetails(P);


            }
            //Catch block for user defined exceptions
            catch (DataEntryException ex)
            {
                Console.WriteLine(ex.Message);

            }
            //Catch block for System defined exceptions
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();




        }

    }
}
