﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathCalLib
{
    /// <summary>
    /// Employee Name: Manish Rahangdale
    /// Description: class Library file for Arithmatic operation on double and integer values
    /// </summary>
    public class ArithmaticOperations
    {
        //Add method for addtition of integers
        public  int AddInt(int num1, int num2)//
        {
            return num1 + num2;
        }

        //SubstractInt method for Substraction of integers
        public int SubstractInt(int num1, int num2)
        {
            return num1 - num2;
        }

        //MultiplyInt method for Multiplication of integers
        public int MultiplyInt(int num1, int num2)
        {
            return num1 * num2;
        }

        //DivideInt method for Division of integers
        public int DivideInt(int num1, int num2)
        {
            return num1 / num2;
        }

        //ModulusInt method for modulus operation of integers
        public int ModulusInt(int num1, int num2)
        {
            return num1 % num2;
        }


        //AddDouble method for addtition of double
        public double AddDouble(double num1, double num2)
        {
            return num1 + num2;
        }

        //SubstractDouble method for substraction of double
        public double SubstractDouble(double num1, double num2)
        {
            return num1 - num2;
        }

        //MultiplyDouble method for multiplication of double
        public double MultiplyDouble(double num1, double num2)
        {
            return num1 * num2;
        }

        //DivideDouble method for division of double
        public double DivideDouble(double num1, double num2)
        {
            return num1 / num2;
        }

        //ModulusDouble method for mudulus operation of double
        public double ModulusDouble(double num1, double num2)
        {
            return num1 % num2;
        }



     

    }
}
