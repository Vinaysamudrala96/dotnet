﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3Q4
{
    class SupplierTest
    {
        static void Main(string[] args)
        {
            Supplier s = new Supplier();
            Supplier s1 = new Supplier();
            Supplier s2;
            s.AcceptDetails(s1);

            s2 = s1.DisplayDetails();
            Console.WriteLine("Supplier Details:");

            Console.Write("Supplier Id:"+s2.SupplierID);
            Console.Write("Supplier Name:"+s2.SupplierName);
            Console.Write("Supplier City:"+s2.City);
            Console.Write("Supplier PhoneNo:"+s2.Phone);
            Console.Write("Supplier Email:"+s2.Email);

            Console.ReadKey();

        }
    }
}
