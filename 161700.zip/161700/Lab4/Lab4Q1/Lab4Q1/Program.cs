﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace EmployeeProject
{

    //Abstract class declaration
    public abstract class Employee
    {

        //Auto properties for get nd set the values of variables
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Department { get; set; }
        public double Salary { get; set; }

        //Abstract method signature 
        public abstract double GetSalary();

    }

    //Class ContractEmployee inherite class Employee and implement method GetSalary
    public class ContractEmployee : Employee
    {
        public int Perks { set; get; }

        //override method GetSalary for providing implementation
        public override double GetSalary()
        {
            return Salary + Perks;
        }
    }

    //Class PermanentEmployee inherite class Employee and implement method GetSalary
    public class PermanentEmployee : Employee
    {
        public int NoOfLeaves { set; get; }
        public int ProvidendFund { set; get; }

        //override method GetSalary for providing implementation
        public override double GetSalary()
        {

            return Salary - ProvidendFund;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int ch;

            do
            {
                //taking user choice 
                WriteLine("*****Menu*****\n\n1.Contract Employee\n2.PErmanent Employee\n");
                Write("Enter your choice:");
                ch = int.Parse(ReadLine());
                switch (ch)
                {
                    //Ading details for Contract Employee
                    case 1:
                        //creating object of class ContractEmployee
                        ContractEmployee c = new ContractEmployee();

                        //taking user inputs
                        WriteLine("enter employee id");
                        c.EmpId = int.Parse(ReadLine());

                        WriteLine("enter employee name");
                        c.EmpName = ReadLine();

                        WriteLine("enter employee department");
                        c.Department = ReadLine();

                        WriteLine("enter employee city");
                        c.City = ReadLine();

                        WriteLine("enter employee address");
                        c.Address = ReadLine();

                        WriteLine("enter employee salary");
                        c.Salary = int.Parse(ReadLine());

                        WriteLine("enter  perks");
                        c.Perks = int.Parse(ReadLine());

                        //Displaying Contract Employee salary
                        WriteLine($"Contract Employee salary is  {c.GetSalary()}");


                        break;

                    //Ading details for Permanent Employee
                    case 2:
                        //creating object of class ContractEmployee
                        PermanentEmployee p = new PermanentEmployee();


                        //taking user inputs
                        WriteLine("enter employee id");
                        p.EmpId = int.Parse(ReadLine());

                        WriteLine("enter employee name");
                        p.EmpName = ReadLine();

                        WriteLine("enter employee department");
                        p.Department = ReadLine();

                        WriteLine("enter employee city");
                        p.City = ReadLine();

                        WriteLine("enter employee address");
                        p.Address = ReadLine();

                        WriteLine("enter employee salary");
                        p.Salary = int.Parse(ReadLine());

                        WriteLine("enter  number of leaves");
                        p.NoOfLeaves = int.Parse(ReadLine());

                        WriteLine("enter Providend fuund");
                        p.ProvidendFund = int.Parse(ReadLine());

                        //Displaying Permanent Employee salary
                        WriteLine($"Permanent Employee salary is { p.GetSalary()}");

                        break;

                        //Exit 
                    case 3:
                        Environment.Exit(0);
                        break;

                        //defaault case for wrong choice
                    default:
                        WriteLine("wrong entry");
                        break;
                }

            } while (ch != 3);


            ReadKey();
        }
    }
}