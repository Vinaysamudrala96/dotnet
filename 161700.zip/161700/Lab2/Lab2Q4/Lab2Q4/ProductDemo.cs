﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Q4
{
    

    class ProductDemo
    {
        //Creating public Auto properties for data member of class 
        public object ProductID { get; set; }
        public object ProductName { get; set; }
        public object Price { get; set; }
        public object Quantity { get; set; }
        public object AmountPayable { get; set; }


        static void Main(string[] args)
        {   
            //Object Creation
            ProductDemo pd = new ProductDemo();

            
            Console.WriteLine("Enter Product Details");

            //Taking User Input for Product ID
            Console.Write("Enter the Id of Product :");
            pd.ProductID = Convert.ToInt32(Console.ReadLine());

            //Taking User Input for Product Name
            Console.Write("Enter the name Product :");
            pd.ProductName = Console.ReadLine();

            //Taking User Input for Product Price
            Console.Write("Enter Price:");
            pd.Price = Convert.ToDouble(Console.ReadLine());

            //Taking User Input for Product Quantity
            Console.Write("Enter Quantity:");
            pd.Quantity = Convert.ToInt32(Console.ReadLine());
            
            //Calclating Amount payable
            pd.AmountPayable = (int)pd.Quantity * (double)pd.Price;

            //Displaying Product details Entered by User
            Console.WriteLine("\n\t*****Product Details*****\n");

            Console.WriteLine("Enter Product ID:"+(int)pd.ProductID);
            Console.WriteLine("Product ID:"+(string)pd.ProductName);
            Console.WriteLine("Product Price:"+(double)pd.Price);
            Console.WriteLine("Product Quantity:"+(int)pd.Quantity);
            Console.WriteLine("Amount Payable:"+(double)pd.AmountPayable);


            Console.ReadKey();


        }
    }
}
