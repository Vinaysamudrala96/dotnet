﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Q5
{
    class BookDemo
    {
        //One Dimentional Array of string declaration for Book details Column field
        private string[] colName = { "Book Title", "Author", "Publisher", "Price" };

        //Two Dimentional Array of string declaration for Book details Row field
        private string[,] bookDetails = new string[2, 4];

        static void Main(string[] args)
        {
            //Creating object of BookDemo Class
            BookDemo bd = new BookDemo();

            //taking User input for book details
            Console.WriteLine("Enter Book Detaiks:");

            //loop for row iteration
            for (int i = 0; i < bd.bookDetails.GetLength(0); i++)
            {
                //loop for column iteration
                for (int j = 0; j <bd.bookDetails.GetLength(1); j++)
                {
                    //taking user input from Console
                    Console.Write("Enter {0}", bd.colName[j]+" : ");
                    bd.bookDetails[i, j] = Console.ReadLine();
                }

            }

            //Displaying Book Details provided by user
            Console.WriteLine("\n\nBook Title\t\tAuthor\t\t\tPublisher\t\tPrice\n");
            //loop for row iteration
            for (int i = 0; i < bd.bookDetails.GetLength(0); i++)
            {
                //loop for column iteration
                for (int j = 0; j < bd.bookDetails.GetLength(1); j++)
                {

                    Console.Write("{0}\t\t\t", bd.bookDetails[i, j]);
                    
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
