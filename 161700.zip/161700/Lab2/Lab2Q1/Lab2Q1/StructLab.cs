﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Q1
{

    //Creation of structure
    public class StructLab
    {
        //Taking integer type variable
        public int Number { get; set; }


        //Square method to fing Square of a number
        public int Square(int Number)
        {
            return (Number * Number);

        }

        //Cube method to fing Cube of a number
        public int Cube(int Number)
        {
            return (Number * Number * Number);

        }

        static void Main(string[] args)
        {
            //Creating object of a structre
            StructLab sl = new StructLab();

            //taking number as a input from user
            Console.WriteLine("Enter number:");
            sl.Number = Convert.ToInt32(Console.ReadLine());

            //taking user choice for finding Square of a number or Cube of a number
            Console.WriteLine("Enter 1 for Square or 2 for Cube of a number:");
            int ch = Convert.ToInt32(Console.ReadLine());

            //Checking user choice and according to that Square and Cube method called
            if (ch == 1)
                Console.WriteLine("Square of number : " + sl.Square(sl.Number));
            else if (ch == 2)
                Console.WriteLine("Cube of number : " + sl.Cube(sl.Number));
            else
                Console.WriteLine("Enter Correct choice:");

            Console.ReadKey();
        }
    }
}
