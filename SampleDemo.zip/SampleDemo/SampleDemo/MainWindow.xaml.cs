﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SampleDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities contextObj = new SampleDemo.Sep19CHNEntities();
            if (txt_location.Text != string.Empty)
            {
                var query = from Emp em in contextObj.Emps
                            where em.empid == 1007 && em.empLoc == txt_location.Text
                            select em;
                List<Emp> eList = new List<SampleDemo.Emp>();
                eList = query.ToList<Emp>();
                if (eList.Count < 0) { MessageBox.Show("no records found"); }
                else
                {
                    dg_emp.ItemsSource = eList;
                }
            }
            else MessageBox.Show("pls enter location");
        }

        private void btn_dlt_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities contextObj = new SampleDemo.Sep19CHNEntities();
                Emp emptobeDeleted;// = new SampleDemo.Emp();
                int empId = Convert.ToInt32(txt_id.Text);
                emptobeDeleted = contextObj.Emps.FirstOrDefault(em => em.empid == empId);
                if (emptobeDeleted != null)
                {
                    contextObj.Emps.Remove(emptobeDeleted);
                    MessageBox.Show("Employee details deleted");
                }
                else throw new Exception("delete could not be done");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
