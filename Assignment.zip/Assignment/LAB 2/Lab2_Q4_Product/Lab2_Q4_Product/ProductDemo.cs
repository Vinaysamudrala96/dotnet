﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_Q4_Product
{
   public class ProductDemo
    {
        private int productID;
        private string productName;
        private double productPrice, amountPayable, productQuantity;
        Object objProductId = null;
        Object objProductName = null;
        Object objProductQuantity = null;
        Object objProductPrice = null;
        Object objProductAmmountPayable = null;
        int unboxxedProductID;
        string unboxxedProductName;
        double unboxxedProductPrice;
        double unboxxedProductQuantity;
        double unboxxedAmountPayable;


        public ProductDemo(int productID, double productQuantity, string productName, double productPrice, double amountPayable)
        {
            this.productID = productID;
            this.productName = productName;
            this.productQuantity = productQuantity;
            this.productPrice = productPrice;
            this.amountPayable = amountPayable;
        }
        public void productBoxing()
        {
            objProductId = productID;
            objProductName = productName;
            objProductQuantity = productQuantity;
            objProductPrice = productPrice;
            objProductAmmountPayable = amountPayable;

        }
        public void productUnboxing()
        {
            unboxxedProductID = (int)objProductId;
            unboxxedProductName = (string)objProductName;
            unboxxedProductPrice = (double)objProductPrice;
            unboxxedProductQuantity = (double)objProductQuantity;
            unboxxedAmountPayable = (double)objProductAmmountPayable;

        }
        public void Display()
        {
            Console.WriteLine("\nProduct Details");
            Console.WriteLine("Product ID : " + unboxxedProductID);
            Console.WriteLine("Product Name :" + unboxxedProductName);
            Console.WriteLine("Price : " + unboxxedProductPrice);
            Console.WriteLine("Quantity : " + unboxxedProductQuantity);
            Console.WriteLine("Amt Payable :" + unboxxedAmountPayable);
        }

    }
}
