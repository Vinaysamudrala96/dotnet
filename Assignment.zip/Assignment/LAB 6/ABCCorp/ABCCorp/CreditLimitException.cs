﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCCorp
{
    class CreditLimitException : ApplicationException
    {
        public CreditLimitException()
            : base()
        { }

        public CreditLimitException(string message)
            : base(message)
        { }
    }
}
