﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cus.Exception
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomerException : ApplicationException
    {
        //Default Constructor
        public CustomerException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public CustomerException(string message)
            : base(message)
        { }
    }
}
