﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cus.Entity;
using Cus.Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace CustomerOperations
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomerOperations
    {
        static List<Customer> empList = new List<Customer>();

        //Method to add new employee
        public static bool AddEmployee(Customer emp)
        {
            bool isAdded = false;

            try
            {
                //Adding employee in the list
                empList.Add(emp);
                isAdded = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }

        //Method to update employee information
        public static bool UpdateEmployee(Customer emp)
        {
            bool isUpdated = false;

            try
            {
                for (int i = 0; i < empList.Count; i++)
                {
                    //Searching employee for modification
                    if (empList[i].EmployeeID == emp.EmployeeID)
                    {
                        //Modifying Employee Details
                        empList[i].EmployeeName = emp.EmployeeName;
                        empList[i].DOJ = emp.DOJ;
                        empList[i].DOB = emp.DOB;
                        empList[i].Salary = emp.Salary;
                        empList[i].Phone = emp.Phone;
                        empList[i].City = emp.City;
                        isUpdated = true;
                    }
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isUpdated;
        }

        //Method to delete particular Employee
        public static bool DeleteEmployee(int empID)
        {
            bool isDeleted = false;

            try
            {
                //Searching the employee for delete
                Customer emp = empList.Find(e => e.EmployeeID == empID);

                if (emp != null)
                {
                    //Deleting Employee information
                    empList.Remove(emp);
                    isDeleted = true;
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isDeleted;
        }

        //Method to search employee information
        public static Customer SearchEmployee(int empID)
        {
           Customer emp = null;

            try
            {
                //Searching employee
                emp = empList.Find(e => e.EmployeeID == empID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }

        //Method to display all employee
        public static List<Customer> DisplayEmployees()
        {
            return empList;
        }

        //Method to Serialize Employee Data
        public static bool SerializeEmployee()
        {
            bool isSerialized = false;

            try
            {
                //Creating object of stream
                FileStream fs = new FileStream("Employee.txt", FileMode.Create, FileAccess.Write);
                //Creating BinaryFormatter object
                BinaryFormatter bin = new BinaryFormatter();
                //Serializing employee data in stream
                bin.Serialize(fs, empList);
                fs.Close();
                isSerialized = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isSerialized;
        }

        //Method to deserialize employee details
        public static List<Customer> DeserializeEmployee()
        {
            List<Customer> empDesList = null;

            try
            {
                //Creating object of stream
                FileStream fs = new FileStream("Employee.txt", FileMode.Open, FileAccess.Read);
                //Creating BinaryFormatter object
                BinaryFormatter bin = new BinaryFormatter();
                //Deserializing employee data from stream
                empDesList = (List<Customer>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDesList;
        }
    }
}
