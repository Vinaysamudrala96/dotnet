﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchCase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any number between 1 to 5");

            int condition= Convert.ToInt32(Console.ReadLine());
            switch(condition)
            {
                case 1:
                    Console.WriteLine("The number entered is 1");
                    break;

                case 2:
                    Console.WriteLine("The number entered is 2");
                    break;

                case 3:
                    Console.WriteLine("The number entered is 3");
                    break;

                case 4:
                    Console.WriteLine("The number entered is 4");
                    break;

                case 5:
                    Console.WriteLine("The number entered is 5");
                    break;

                default:
                    Console.WriteLine("error:Enter a valid number");
                    break;
            }
            Console.ReadKey();
        }
    }
}
