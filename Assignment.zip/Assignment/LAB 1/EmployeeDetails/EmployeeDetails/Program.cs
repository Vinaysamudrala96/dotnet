﻿//Library files 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLib;//dll file from EmployeeLib

namespace EmployeeDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] emp = new Employee[10];//Creation and Initilization of Array

            for (int i = 0; i < emp.Length; i++)
            {
                emp[i] = new Employee();//Object to hold the values for a particular loop
                Console.WriteLine("EmployeeID:");

                //User inputs
                emp[i].EmployeeID = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("EmployeeName:");
                emp[i].EmployeeName = Console.ReadLine();

                Console.WriteLine("EmployeeAddress:");
                emp[i].EmployeeAddress = Console.ReadLine();

                Console.WriteLine("EmployeeCity:");
                emp[i].EmployeeCity = Console.ReadLine();

                Console.WriteLine("EmployeeDepartment:");
                emp[i].EmployeeDepartment = Console.ReadLine();

                Console.WriteLine("EmployeeSalary:\n");
                emp[i].Salary = Convert.ToDouble(Console.ReadLine());
            }
            //Displaying Name and Salary of Employee
            Console.WriteLine("*******Employee Details*****");

            for (int i = 0; i < emp.Length; i++) 
            {
                
                Console.WriteLine((i + 1) + "." + "Employee Name:" + emp[i].EmployeeName);
                Console.WriteLine("  Employee Salary:" + emp[i].Salary);
                
            }
            Console.ReadKey();
            }
        }
    }

