﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentDetails
{
    class Program
    {
        private int rollNumber;
        private string studentName;
        private byte age;
        private char gender;
        private DateTime dateOfBirth;
        private string address;
        private float percentage;

        private Program()
        {
            rollNumber = 101;
            studentName = "Joy";
            dateOfBirth = DateTime.Parse("03/02/2005");
            age = 13;
            gender = 'M';
            address = "Capgemini,Sipcot";
            percentage = 92.10f;
        }

        static void Main(string[] args)
        {
            Program sc = new Program();
            Console.WriteLine("Roll Number : {0}", sc.rollNumber);
            Console.WriteLine("Name: {0}", sc.studentName);
            Console.WriteLine("Age : {0}", sc.age);
            Console.WriteLine("Gender: {0}", sc.gender);
            Console.WriteLine("Date of Birth: {0}", sc.dateOfBirth);
            Console.WriteLine("Address:{0} ", sc.address);
            Console.WriteLine("Percentage:{0} ", sc.percentage);
            Console.ReadKey();

        }
    }
}
