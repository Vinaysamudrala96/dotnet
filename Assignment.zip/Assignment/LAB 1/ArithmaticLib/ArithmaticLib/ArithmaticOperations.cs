﻿//Library Files
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArithmaticLib
{
    public class ArithmaticOperations
    {
        public int AddInt(int num1,int num2)
        {
            return num1 + num2;
        }

        public int SubtractInt(int num1, int num2)
        {
            return num1 - num2;
        }

        public int MultiplyInt(int num1, int num2)
        {
            return num1 * num2;
        }

        public int DivInt(int num1, int num2)
        {
            return num1 / num2;
        }

        public int ModInt(int num1, int num2)
        {
            return num1 % num2;
        }





        public double AddDouble(double num1, double num2)
        {
            return num1 + num2;
        }

        public double SubtractDouble(double num1, double num2)
        {
            return num1 - num2;
        }

        public double MultiplyDouble(double num1, double num2)
        {
            return num1 * num2;
        }

        public double DivDouble(double num1, double num2)
        {
            return num1 / num2;
        }

        public double ModDouble(double num1, double num2)
        {
            return num1 % num2;
        }
    }
}
