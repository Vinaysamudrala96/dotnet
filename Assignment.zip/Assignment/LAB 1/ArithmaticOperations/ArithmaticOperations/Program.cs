﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArithmaticLib;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            int c, n;
            Char choice;
            do
            {
                ArithmaticOperations ar = new ArithmaticOperations();
                Console.WriteLine("******Menu****** \n 1.Addition \n 2.Substraction \n 3.Multiplication \n 4.Division \n 5.Modulus \n 6.Exit\n\n\n");
                Console.WriteLine("Enter Your Choice");//User selecting Operation to be performed
                c = Convert.ToInt32(Console.ReadLine());

                switch (c)
                {
                    case 1:
                        Console.WriteLine("Enter 1 for Calculation of Numbers \n Enter 2 for Calculation of Decimal Numbers");
                        n = Convert.ToInt32(Console.ReadLine());

                        if (n == 1)
                        {
                            Console.WriteLine("Enter First Number ");
                            int num1 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Second Number ");
                            int num2 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Result=>" + ar.AddInt(num1, num2));
                        }
                        else if (n == 2)
                        {
                            Console.WriteLine("Enter First Number ");
                            double num1 = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Enter Second Number ");
                            double num2 = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Result=>" + ar.AddDouble(num1, num2));
                        }
                        else
                            Console.WriteLine("Enter 1 for Calculation of Numbers \n Enter 2 for Calculation of Decimal Numbers");
                        break;

                    case 2:
                        Console.WriteLine("Enter 1 for Calculation of Numbers \n Enter 2 for Calculation of Decimal Numbers");
                        n = Convert.ToInt32(Console.ReadLine());

                        if (n == 1)
                        {
                            Console.WriteLine("Enter First Number ");
                            int num1 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Second Number ");
                            int num2 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Result=>" + ar.SubtractInt(num1, num2));
                        }
                        else if (n == 2)
                        {
                            Console.WriteLine("Enter First Number ");
                            double num1 = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Enter Second Number ");
                            double num2 = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Result=>" + ar.SubtractDouble(num1, num2));
                        }
                        else
                            Console.WriteLine("Enter 1 for Calculation of Numbers \n Enter 2 for Calculation of Decimal Numbers");
                        break;

                    case 3:
                        Console.WriteLine("Enter 1 for Calculation of Numbers \n Enter 2 for Calculation of Decimal Numbers");
                        n = Convert.ToInt32(Console.ReadLine());

                        if (n == 1)
                        {
                            Console.WriteLine("Enter First Number ");
                            int num1 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Second Number ");
                            int num2 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Result=>" + ar.MultiplyInt(num1, num2));
                        }
                        else if (n == 2)
                        {
                            Console.WriteLine("Enter First Number ");
                            double num1 = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Enter Second Number ");
                            double num2 = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Result=>" + ar.MultiplyDouble(num1, num2));
                        }
                        else
                            Console.WriteLine("Enter 1 for Calculation of Numbers \n Enter 2 for Calculation of Decimal Numbers");
                        break;

                    case 4:
                        Console.WriteLine("Enter 1 for Calculation of Numbers \n Enter 2 for Calculation of Decimal Numbers");
                        n = Convert.ToInt32(Console.ReadLine());

                        if (n == 1)
                        {
                            Console.WriteLine("Enter First Number ");
                            int num1 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Second Number ");
                            int num2 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Result=>" + ar.DivInt(num1, num2));
                        }
                        else if (n == 2)
                        {
                            Console.WriteLine("Enter First Number ");
                            double num1 = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Enter Second Number ");
                            double num2 = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Result=>" + ar.DivDouble(num1, num2));
                        }
                        else
                            Console.WriteLine("Enter 1 for Calculation of Numbers \n Enter 2 for Calculation of Decimal Numbers");
                        break;


                    case 5:
                        Console.WriteLine("Enter 1 for Calculation of Numbers \n Enter 2 for Calculation of Decimal Numbers");
                        n = Convert.ToInt32(Console.ReadLine());

                        if (n == 1)
                        {
                            Console.WriteLine("Enter First Number ");
                            int num1 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Second Number ");
                            int num2 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Result=>" + ar.ModInt(num1, num2));
                        }
                        else if (n == 2)
                        {
                            Console.WriteLine("Enter First Number ");
                            double num1 = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Enter Second Number ");
                            double num2 = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Result=>" + ar.ModDouble(num1, num2));
                        }
                        else
                            Console.WriteLine("Enter 1 for Calculation of Numbers \n Enter 2 for Calculation of Decimal Numbers");
                        break;
                    default:
                        Console.WriteLine("Please check the Operation selected");
                        break;
                }
                Console.WriteLine("Enter 'Y' or 'y' to continue or 'n' to Exit");
                c = Convert.ToChar(Console.ReadLine());




            } while (c == 'y' || c == 'Y');
        }
    }
}
