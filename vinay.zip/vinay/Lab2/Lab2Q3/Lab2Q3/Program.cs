﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            //taking size of array from user
            Console.Write("How many City name you want to Add:");
            int size = Convert.ToInt32(Console.ReadLine());
            string[] City = new string[size];

            //loop for taking City name from user
            for (int i = 0; i < City.Length; i++)
            {
                Console.Write("Enter city name for city number {0}:", (i + 1));
                City[i] = Console.ReadLine();
            }

            //foeeach loop for display city names entered by user
            Console.WriteLine("Your Entries are:");
            foreach (string s in City)
            {
                Console.WriteLine(s);
            }

            Console.ReadKey();
        }
    }
}
