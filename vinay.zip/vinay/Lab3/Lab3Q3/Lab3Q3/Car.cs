﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3Q3
{
    class Car
    {
        //auto propertoies for Car Class
        public string Maker { get; set; }
        public int Model { get; set; }
        public int Year { get; set; }
        public double SalePrice { get; set; }

        //default Constructor for Car Class
        public Car()
        {
            this.Maker = "";
            this.Model = 0;
            this.Year = 0;
            this.SalePrice = 0.0;

        }

        //Parameterized Constructor for Car Class
        public Car(string maker, int model, int year, double salesprice)
        {
            this.Maker = maker;
            this.Model = model;
            this.Year = year;
            this.SalePrice = salesprice;

        }

        static void Main(string[] args)
        {
            //count will bw use for count the number of records
            //t work as flag
            //temp is for temporary storage
            int count = 0, t = 0, temp;
            int ch;
            //Creating array of object for Car Class 
            Car[] c = new Car[15];

            do
            {

                Console.WriteLine("\n\n*****Menu*****");
                Console.WriteLine("\n1.Add new Car\n2.Modify Car Details\n3.Search for Car\n4.List All the call\n5.Delete Car Details\n6.Quit\n**************");

                //Taking User choice for operation
                Console.Write("Enter your choice:");
                 ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    // Add New car details
                    case 1:

                        Console.WriteLine("Enter Car Details:");

                        Console.Write("Enter Maker of car:");
                        string maker = Console.ReadLine();

                        Console.Write("Enter Model of car:");
                        int model = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter Year of car:");
                        int year = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter Sale price  of car:");
                        double price = double.Parse(Console.ReadLine());

                        //initializing values using parameterized Constructor
                        c[count] = new Car(maker, model, year, price);
                        count++;
                        break;

                    //case 2 for Modify details
                    case 2:

                        //taking model number for find the record
                        Console.Write("Enter Model of car which details you want to Modify:");
                        temp = Convert.ToInt32(Console.ReadLine());
                        t = 0;
                        //loop  for find the record
                        for (int i = 0; i < count; i++)
                        {
                            if (temp == c[i].Model)
                            {
                                //modifying details if record found by taking new details from user 
                                Console.Write("Enter Maker of car:");
                                c[i].Maker = Console.ReadLine();

                                Console.Write("Enter Year of car:");
                                c[i].Year = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Enter Sale price  of car:");
                                c[i].SalePrice = double.Parse(Console.ReadLine());

                                t = 1;

                            }
                        }
                        if (t == 0)
                            Console.WriteLine("Details Not Found ");

                        break;

                    //case 3 for display details of perticular Car 
                    case 3:
                        //taking model number for find the record
                        Console.Write("Enter Model of car which details you want to show:");
                        temp = Convert.ToInt32(Console.ReadLine());
                        t = 0;
                        //loop  for searching the record
                        for (int i = 0; i < count; i++)
                        {
                            if (temp == c[i].Model)
                            {
                                //Displaying details of car if record found
                                Console.WriteLine("Car Details For model: {0}", temp);
                                Console.WriteLine("Maker\t\tModel\t\tYear\t\tSales Price");
                                Console.WriteLine(c[i].Maker + "\t\t" + c[i].Model + "\t\t" + c[i].Year + "\t\t" + c[i].SalePrice);
                                t = 1;
                                break;

                            }


                        }
                        if (t == 0)
                            Console.WriteLine("Details Not Found ");
                        break;

                    //case 4 for display details of All Car 
                    case 4:
                        Console.WriteLine("Car Details For model:");
                        Console.WriteLine("Maker\t\tModel\t\tYear\t\tSales Price");
                        //loop for iterating array
                        for (int i = 0; i < count; i++)
                        {
                            Console.WriteLine(c[i].Maker + "\t\t" + c[i].Model + "\t\t" + c[i].Year + "\t\t" + c[i].SalePrice);
                        }

                        break;

                    //case 5 for delete details of perticular Car 
                    case 5:
                        //taking model number for find the record
                        Console.WriteLine("Enter model number whose details want to delete:");
                        temp = Convert.ToInt32(Console.ReadLine());
                        t = 0;
                        for (int i = 0; i < count; i++)
                        {
                            if (temp == c[i].Model)
                            {
                                //Displaying details of car if record found 
                                Console.WriteLine("Maker\t\tModel\t\tYear\t\tSales Price");
                                Console.WriteLine(c[i].Maker + "\t\t" + c[i].Model + "\t\t" + c[i].Year + "\t\t" + c[i].SalePrice);
                               
                                //removing details of car by making object null 
                                c[i] = null;

                                Console.WriteLine("\n\nDetails are deleted for Car Model:" + temp);
                                //loop for shifting objects to vacant space in array in left direction
                                for (int j = i + 1; j < count; j++)
                                {
                                    c[i] = c[j];
                                    i++;
                                }
                                count--;
                                break;

                            }

                        }
                        if (t == 0)
                            Console.WriteLine("Details Not Found ");
                        break;

                    //case 6 for Exit
                    case 6:
                        Environment.Exit(0);
                        break;

                    //case 6 for default case for invalid choice
                    default:
                        Console.WriteLine("Enter correct choice");
                        break;
                }

            } while (ch!=6);

        }
    }
}
