﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3Q2
{
    public class Bird //class should be public
    {
        public string Name;
        public double Maxheight;

        public Bird()  //Default Constructor
        {
            this.Name = "Mountain Eagle";// string should be in double qoats
            this.Maxheight = 500;// there is no requirement of Qoats in double type values

            //
            // TODO: Add constructor logic here
            //
        }

        public Bird(string birdname, double max_ht) //Overloaded Constructor
        {
            this.Name = birdname ;//variable name should be use from parameter list
            this.Maxheight = max_ht;// variable name should be use from parameter list
        }

        public void fly()
        {
            Console.WriteLine(this.Name+ " is flying at altitude  " +this.Maxheight);//variable should not be in double qouts 
        }

        public void fly(double AtHeight)// parameter type should be double
        {
            if (AtHeight <= this.Maxheight)
                Console.WriteLine(this.Name + " flying at  " + AtHeight.ToString());
            else//"if" is not required

                Console.WriteLine(this.Name+"cannot fly at  " +this.Maxheight);//variable should not be in double qouts and variable name is "MaxHeight" not "height" 
        }



        static void Main(string[] args)
        {

            Bird b = new Bird("Eagle" , double.Parse("200"));// for Eagle and 200 double qouts required not single Qouts
            b.fly();
            b.fly(double.Parse("300"));// for 200 double qouts required not single Qouts

            Console.ReadKey();//hold the console for view result

        }

    }

}
