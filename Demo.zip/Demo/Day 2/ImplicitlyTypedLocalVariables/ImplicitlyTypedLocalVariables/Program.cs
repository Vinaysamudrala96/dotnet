﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplicitlyTypedLocalVariables
{
    class Program
    {
        static void Main(string[] args)
        {
            //var val;       //Error: Implicitly Typed Local Variables Must be Initialized

            //var val = null;  //Error: Cannot assign null to an Implicitly Typed Local Variables
            var str = "Capgemini";
            str = null;

            //  var arr = { 1, 2, 3, 4, 5 }; // Error: cannot initialize an Implicitly Typed Local Variables with an Array Initializer

            var arr = new int[] { 1, 2, 3, 4, 5 };

            var num =10.5;
           // num = false;

            float f = 34.76f;

            Console.ReadKey();


        }
    }
}
