﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            Console.Write("Enter EmployeeId:");
                emp.EmployeeID = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Employee Name:");
            emp.EmployeeName = Console.ReadLine();
            Console.Write("Enter Employee Salary:");
            emp.Salary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Enter EmployeeId:"+ emp.EmployeeID);
            Console.WriteLine("Enter Employee Name:"+emp.EmployeeName);
            Console.WriteLine("Enter Employee Salary:"+emp.Salary);
            Console.ReadKey();
        }
    }
}
