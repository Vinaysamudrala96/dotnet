﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoImplementedProperties
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.EmployeeId = 101;
            emp.EmployeeName = "robert";
            emp.Salary = 10000;

            Console.WriteLine("Id:",emp.EmployeeId);
            Console.WriteLine(emp.EmployeeName);
            Console.WriteLine("Salary:" +""+ emp.Salary);
            Console.ReadKey();



        }
    }
}
