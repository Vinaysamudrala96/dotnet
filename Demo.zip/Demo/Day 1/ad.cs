using System;

public class Ad
{
	public static void Main(string[] args)
	{
		int l1=int.Parse(args[0]+args[1]);
		
		Console.WriteLine(l1);
		
	}
}