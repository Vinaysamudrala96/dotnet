﻿select * from VinaySam.Employee
create table VinaySam.Employ
( empno int primary key,
empname varchar(50) not null,
empsal numeric(10,2) check(empsal >= 25000) ,
emptype varchar(1) check(emptype in('C','P'))
)

create proc VinaySam.SearchEmployById
@eno int
as
begin
select * from VinaySam.Employ where empno = @eno
end


exec VinaySam.SearchEmployeeById 1000
insert into VinaySam.Employ values(1000,'vinay',30000,'C')
insert into VinaySam.Employ values(1001,'ram',40000,'P')
select * from VinaySam.Employe

create proc VinaySam.DeleteEmployeeById
@eno int
as
begin
delete from VinaySam.Employ where empno=@eno
end

exec VinaySam.DeleteEmployeeById 1001

select ident_current('VinaySam.Employe')+ident_incr('VinaySam.Employe')
create proc VinaySam.usp_AddEmploy
@eName varchar(20),
@esal int,
@etype varchar(20)
AS
BEGIN
insert into Vinaysam.Employe values(@eName,@esal,@etype)
end

insert into Vinaysam.Employe values('ac',55555,'C')

select * from Vinaysam.Employe