﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoDarray
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            int[,] arr = new int[5, 6];

            Console.Write("\n\nRead a 2D array of size 3x3 and print the matrix :\n");
            Console.Write("------------------------------------------------------\n");


            /* Stored values into the array*/
            Console.Write("Input elements in the matrix :\n");
            for (i = 0; i < arr.GetLength(0); i++)
            {
                for (j = 0; j < arr.GetLength(1); j++)
                {
                    Console.Write("element - [{0},{1}] : ", i, j);
                    arr[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.Write("\nThe matrix is : \n");
            for (i = 0; i < arr.GetLength(0); i++)
            {
                Console.Write("\n");
                for (j = 0; j < arr.GetLength(1); j++)
                    Console.Write("{0}\t", arr[i, j]);
            }
            Console.Write("\n\n");
            Console.ReadKey();
        }
    }
}
