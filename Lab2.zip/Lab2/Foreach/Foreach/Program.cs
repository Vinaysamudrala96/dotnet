﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Foreach
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arr = new string[10];
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                Console.WriteLine("enter the city name" + (i+1));
                arr[i] = Console.ReadLine();
            }
            foreach (string city in arr)
            {
                Console.WriteLine(city);
            }
            Console.ReadKey();
        }
    }
}
