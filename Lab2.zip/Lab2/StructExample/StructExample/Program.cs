﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructExample
{ 
    class Program
    {
        public struct Operations
        {
            int result;
            int num;
            public int Number
            {
                get { return num; }
                set {  num=value; }
            }
            public int Result(int ch)
            {
              
                
                int choice = ch;
                char continu,c;
                
                    switch (choice)
                    {
                        case 1:
                            result = num * num;
                            Console.WriteLine("square of the number is :" + result);
                            break;
                        case 2:
                            result = num * num * num;
                            Console.WriteLine("cube of the number is :" + result);
                            break;
                        default:
                            Console.WriteLine("Enter valid choice");
                            break;
                    }
                    return result;


                   
                
               
                
            }
        }
        static void Main(string[] args)
        {
            Operations op = new Operations();
            char c;
                do { 
            Console.WriteLine("Enter the number is " );
            op.Number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the choice  \n 1:square \n 2:cube ");
            int ch= Convert.ToInt32(Console.ReadLine());
            op.Result(ch);
                Console.WriteLine("Do you want to continue:");
                c = Convert.ToChar(Console.ReadLine());
            } while (c == 'y');
            Console.ReadKey();
        }
    }
}
