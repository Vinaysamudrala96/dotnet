﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CreateCookies
{
    public partial class ShowCookies : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie hc= Request.Cookies["c1"];
            
            if (hc != null)
            {
                Label1.Text = "Cookie 1 : " + hc.Value;
            }
            else
            {
                Label1.Text = "Cookie not created";
            }
            hc = Request.Cookies["c2"];
            if (hc.HasKeys)
            {
                foreach (string str in hc.Values)
                {
                    Label2.Text += "<li>" + str + " is " + Request.Cookies["c2"][str];
                }
            }
        }
    }
}